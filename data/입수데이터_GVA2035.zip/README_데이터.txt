산업별 실질부가가치 전망 (2025-2035) — 입수 데이터
=====================================================
출처: 한국은행 ECOS, 통계청 KOSIS 장래인구추계, FRED

[GDP·산업]
 gdp_quarterly_sa.csv      : 실질GDP 분기(계절조정, 명목/실질/디플레이터) 1960Q1~
 gdp_industry_long.csv     : 36개 산업 실질·명목 부가가치(분기) 1980Q1~2025Q4
[산업연관표]
 io_생산유발계수_long.csv   : 생산유발계수표(2015~2023, 대분류)
 io_투입계수_long.csv       : 투입계수표(2015~2023, 대분류)
 io_sectors.csv            : 대분류 산업 목록
[거시 외생변수]
 exog_quarterly.csv        : 유가·교역량·실질금리·실질환율·취업자(원자료, 변환 전후)
 exog_quarterly_filled.csv : 1990년대 취업자 칼만평활 복원 포함(정상성 변환 완료)
[인구]
 kosis_생산연령인구.csv     : 생산연령인구 추계 중위/고위/저위(2015~2040)
 kosis_wap_historical.csv  : 생산연령인구 1990~2026(중위)

전체 코드·산출물: https://github.com/sdkparkforbi/gva-scenario-2025-2035
